public class Numeros {
    private static double primeiroValor;
    private static double segundoValor;
    private static double resultado;


    public static double getPrimeiroValor() {
        return primeiroValor;
    }

    public static void setPrimeiroValor(double primeiroValor) {
        Numeros.primeiroValor = primeiroValor;
    }

    public static double getSegundoValor() {
        return segundoValor;
    }

    public static void setSegundoValor(double segundoValor) {
        Numeros.segundoValor = segundoValor;
    }

    public static double getResultado() {
        return resultado;
    }

    public static void setResultado(double resultado) {
        Numeros.resultado = resultado;
    }
}
