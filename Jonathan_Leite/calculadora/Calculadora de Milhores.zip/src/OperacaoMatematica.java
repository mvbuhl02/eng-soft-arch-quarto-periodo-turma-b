public interface OperacaoMatematica {
    void calcular();
}
